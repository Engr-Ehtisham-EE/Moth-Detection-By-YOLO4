% Load the dataset from a .mat file
data = load("combined_data.mat");
moth = data.combinedData;

% Display the first few rows of the data
disp(moth(1:4,:));

% Add the full path to image filenames
moth.imageFilename = fullfile(pwd, moth.FileName);

% Shuffle the dataset and split it
rng("default");
shuffledIndices = randperm(height(moth));

% Split data into training, validation, and test sets
numTrain = floor(0.6 * length(shuffledIndices));    % 60% for training
numValidation = floor(0.1 * length(shuffledIndices)); % 10% for validation

trainingIdx = 1:numTrain;
trainingDataTbl = moth(shuffledIndices(trainingIdx), :);

validationIdx = numTrain + 1 : numTrain + numValidation;
validationDataTbl = moth(shuffledIndices(validationIdx), :);

testIdx = validationIdx(end) + 1 : length(shuffledIndices);
testDataTbl = moth(shuffledIndices(testIdx), :);

% Rename the 'BoundingBoxes' variable to 'Moth' in each data table
trainingDataTbl = renamevars(trainingDataTbl, "BoundingBoxes", "Moth");
validationDataTbl = renamevars(validationDataTbl, "BoundingBoxes", "Moth");
testDataTbl = renamevars(testDataTbl, "BoundingBoxes", "Moth");

% Create datastores
imdsTrain = imageDatastore(trainingDataTbl{:,"FileName"});
bldsTrain = boxLabelDatastore(trainingDataTbl(:,"Moth"));

imdsValidation = imageDatastore(validationDataTbl{:,"FileName"});
bldsValidation = boxLabelDatastore(validationDataTbl(:,"Moth"));

imdsTest = imageDatastore(testDataTbl{:,"FileName"});
bldsTest = boxLabelDatastore(testDataTbl(:,"Moth"));

% Combine image and label datastores
trainingData = combine(imdsTrain, bldsTrain);
validationData = combine(imdsValidation, bldsValidation);
testData = combine(imdsTest, bldsTest);

% Validate input data
validateInputData(trainingData);
validateInputData(validationData);
validateInputData(testData);

% Display one of the training images and its bounding boxes
data = read(trainingData);
I = data{1};
bbox = data{2};
annotatedImage = insertShape(I,"Rectangle",bbox);
annotatedImage = imresize(annotatedImage,2);
figure
imshow(annotatedImage);

reset(trainingData);

% Define input size for model training
inputSize = [416, 416, 3];

% Define the class name for the object detection task
className = "Moth";

% Estimate Anchor Boxes
numAnchors = 6;  % Number of anchors
trainingDataForEstimation = transform(trainingData, @(data) preprocessData(data, inputSize));
[anchors, meanIoU] = estimateAnchorBoxes(trainingDataForEstimation, numAnchors);

% Sort anchors by area and assign to detection heads
area = anchors(:, 1) .* anchors(:, 2);
[~, idx] = sort(area, "descend");

anchors = anchors(idx, :);
anchorBoxes = {anchors(1:3, :); anchors(4:6, :)};

% Create YOLO v4 detector
detector = yolov4ObjectDetector("tiny-yolov4-coco", "Moth", anchorBoxes, InputSize=inputSize);

% Perform Data Augmentation on Training Data
augmentedTrainingData = transform(trainingData, @augmentData);

% Display examples of augmented training data
augmentedData = cell(4, 1);
for k = 1:4
    data = read(augmentedTrainingData);
    augmentedData{k} = insertShape(data{1}, "rectangle", data{2});
    reset(augmentedTrainingData);
end
figure
montage(augmentedData, BorderSize=10)

% Specify Training Options
options = trainingOptions("adam", ...
    GradientDecayFactor=0.9, ...
    SquaredGradientDecayFactor=0.999, ...
    InitialLearnRate=0.001, ...
    LearnRateSchedule="none", ...
    MiniBatchSize=4, ...
    L2Regularization=0.0005, ...
    MaxEpochs=100, ...
    DispatchInBackground=true, ...
    ResetInputNormalization=true, ...
    Shuffle="every-epoch", ...
    VerboseFrequency=20, ...
    ValidationFrequency=1000, ...
    CheckpointPath=tempdir, ...
    ValidationData=validationData, ...
    OutputNetwork="best-validation-loss");

% Train or Load Pretrained Detector
doTraining = true;  % Set to true to train, false to use pretrained detector
if doTraining       
    % Train the YOLO v4 detector
    [detector, info] = trainYOLOv4ObjectDetector(augmentedTrainingData, detector, options);
else
    % Load pretrained detector for the example
    detector = downloadPretrainedYOLOv4Detector();
end
% Specify the path and filename to save the trained detector as 'Moth_detector.mat'
modelPath = fullfile(pwd, 'Moth_detector.mat');

% Save the trained detector to a .mat file
save(modelPath, 'detector', '-v7.3');  % -v7.3 handles larger files if needed

disp(['Trained YOLO v4 detector saved as Moth_detector.mat in: ', modelPath]);

%End of Training
%Don't clear all the variables in from the training script when you go for
%testing
%Use testing.m for testing of the image