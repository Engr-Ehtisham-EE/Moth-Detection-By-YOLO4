% Define the main folder path
mainFolder = 'D:\Moth_Detection\dataset\train';

% Define folders for images and annotations within the main path
imageFolder = fullfile(mainFolder, 'Images');       % Folder where images are stored
annotationFolder = fullfile(mainFolder, 'Annotations'); % Folder where annotations are stored

% Supported image extensions (e.g., jpg, png, jpeg)
imageExtensions = {'*.jpg', '*.jpeg', '*.png'};

% Get list of image files with supported extensions
imageFiles = [];
for k = 1:numel(imageExtensions)
    imageFiles = [imageFiles; dir(fullfile(imageFolder, imageExtensions{k}))];
end

% Initialize cell arrays for storing filenames, bounding boxes, and labels
filenames = cell(numel(imageFiles), 1);
bboxData = cell(numel(imageFiles), 1); % Store bounding box data
labelData = cell(numel(imageFiles), 1); % Store label data

% Loop through each image file
for i = 1:numel(imageFiles)
    % Get the filename without extension
    [~, name, ~] = fileparts(imageFiles(i).name);

    % Store the image filename with path
    filenames{i} = fullfile(imageFolder, imageFiles(i).name);

    % Read annotation from the corresponding YOLO format text file
    annotationFile = fullfile(annotationFolder, [name, '.txt']);
    if isfile(annotationFile)
        fileID = fopen(annotationFile, 'r');
        
        % Read each line as a row of YOLO data (format: class_id center_x center_y width height)
        annotations = fscanf(fileID, '%f', [5, Inf])';
        fclose(fileID);

        % Check if any annotations were read
        if ~isempty(annotations)
            % Number of bounding boxes
            numBoxes = size(annotations, 1);

            % Load the image to get its dimensions
            img = imread(filenames{i});
            [imgHeight, imgWidth, ~] = size(img);

            % Convert normalized YOLO bounding boxes to absolute pixel coordinates
            % YOLO format: [center_x, center_y, width, height] (normalized)
            % Convert to MATLAB format: [x, y, width, height] (absolute)
            boundingBoxes = [ ...
                max(1, round((annotations(:, 2) - annotations(:, 4) / 2) * imgWidth)), ... % x
                max(1, round((annotations(:, 3) - annotations(:, 5) / 2) * imgHeight)), ... % y
                round(annotations(:, 4) * imgWidth), ...                                   % width
                round(annotations(:, 5) * imgHeight)                                       % height
            ];

            % Ensure bounding boxes are within image boundaries
            boundingBoxes(:, 1) = min(boundingBoxes(:, 1), imgWidth);
            boundingBoxes(:, 2) = min(boundingBoxes(:, 2), imgHeight);
            boundingBoxes(:, 3) = min(boundingBoxes(:, 3), imgWidth - boundingBoxes(:, 1));
            boundingBoxes(:, 4) = min(boundingBoxes(:, 4), imgHeight - boundingBoxes(:, 2));

            % Set all labels to "Moth" regardless of class ID
            labels = repmat(categorical("Moth"), numBoxes, 1);
            
            % Store bounding boxes and labels
            bboxData{i} = boundingBoxes;
            labelData{i} = labels;
        else
            % No valid annotation data; label as "No annotation"
            bboxData{i} = [];
            labelData{i} = categorical("No annotation");
        end
    else
        % No annotation file found: set label as "No annotation"
        bboxData{i} = [];
        labelData{i} = categorical("No annotation");
    end
end

% Combine data into a table formatted for boxLabelDatastore input
combinedData = table(filenames, bboxData, labelData, 'VariableNames', {'FileName', 'BoundingBoxes', 'Labels'});

% Save the data into a .mat file
save('combined_data.mat', 'combinedData');

% Display the combined data table
disp(combinedData);
