% Load the trained detector if not already loaded
if ~exist('detector', 'var')
    loadedData = load('Moth_detector.mat');
    detector = loadedData.detector;
end

% Define the path to the folder containing test images
testImageFolder = 'D:\Moth_Detection\dataset\test\images';  % Replace with your test folder path

% Create an image datastore for all images in the test folder
imdsTest = imageDatastore(testImageFolder);

% Loop through each image in the test dataset
for i = 1:numel(imdsTest.Files)
    % Read the test image
    I = readimage(imdsTest, i);

    % Run object detection on the image
    [bboxes, scores, labels] = detect(detector, I, 'Threshold', 0.5);

    % Display the image with detected bounding boxes
    annotatedImage = I;
    if ~isempty(bboxes)
        % Annotate detected bounding boxes on the image
        annotatedImage = insertShape(I, 'Rectangle', bboxes, 'Color', 'green', 'LineWidth', 3);

        % Display detection scores and labels
        for j = 1:size(bboxes, 1)
            position = bboxes(j, 1:2);  % Top-left corner for the text
            label = sprintf('%s: %.2f', labels(j), scores(j));
            annotatedImage = insertText(annotatedImage, position, label, 'BoxColor', 'green', 'FontSize', 12);
        end
    else
        disp(['No detections found in image: ', imdsTest.Files{i}]);
    end

    % Show the annotated image with detections
    figure;
    imshow(annotatedImage);
    title(['Detected Objects in Image ', num2str(i)]);
    
    % Optionally pause to inspect each image (remove or adjust the pause time as needed)
    pause(1);  % Pause for 1 second before showing the next image
end
