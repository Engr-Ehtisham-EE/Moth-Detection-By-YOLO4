function data = preprocessData(data, targetSize)
    % Resize images and adjust bounding boxes for training input size

    for i = 1:size(data,1)
        I = data{i,1};
        bboxes = data{i,2};

        % Resize image to the target size and normalize pixel values
        I = im2single(imresize(I, targetSize(1:2)));

        % Scale bounding boxes based on image resizing
        scale = targetSize(1:2) ./ size(I, [1 2]);
        bboxes = bboxresize(bboxes, scale);

        % Update data with resized image and adjusted bounding boxes
        data{i, 1} = I;
        data{i, 2} = bboxes;
    end
end
