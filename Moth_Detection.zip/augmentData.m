function data = augmentData(data)
    % Apply random horizontal flipping, random scaling, and color jittering.
    
    for i = 1:size(data, 1)
        I = data{i, 1};
        bboxes = data{i, 2};

        % Apply color jitter (adjust contrast, hue, saturation, brightness)
        if size(I, 3) == 3  % Check if the image is in color
            I = jitterColorHSV(I, ...
                'Contrast', 0.0, ...
                'Hue', 0.1, ...
                'Saturation', 0.2, ...
                'Brightness', 0.2);
        end

        % Randomly flip image horizontally
        if rand > 0.5
            I = flip(I, 2);  % Flip horizontally
            % Adjust bounding boxes for horizontal flip
            bboxes(:, 1) = size(I, 2) - bboxes(:, 1) - bboxes(:, 3);
        end

        % Apply random scaling (between 90% and 110%)
        scaleFactor = 1 + 0.1 * (rand - 0.5);
        tform = randomAffine2d('Scale', [scaleFactor, scaleFactor]);
        rout = affineOutputView(size(I), tform, 'BoundsStyle', 'centerOutput');
        I = imwarp(I, tform, 'OutputView', rout);

        % Warp bounding boxes with the same transformation
        [warpedBBoxes, indices] = bboxwarp(bboxes, tform, rout, 'OverlapThreshold', 0.25);

        % If boxes remain after warping, assign augmented data; otherwise, keep original
        if ~isempty(indices)
            data{i, 1} = I;
            data{i, 2} = warpedBBoxes;
        end
    end
end
